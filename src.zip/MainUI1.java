import java.awt.*;
import java.awt.event.*;
import javax.swing.*;

class MainUI1 extends JFrame implements ActionListener
{
	StakeholderUI ob1;
	InvestorUI ob2;
	FinanceUI ob3;
	Customer_RelationUI ob4;
	SalesUI ob5;
	InventoryUI ob6;
	VendorUI ob7;
	ProductionUI ob8;
	
	
	JButton submit,modify,delete,m1,m2,m3,m4,m5,m6,m7,m8;
	JPanel p1,p2,p3,p4,p5,p6,p7,p8,pb;
	JMenuBar mb;
	
	public MainUI1()
	{
		setSize(600,550);
		setLayout(null);
		setVisible(true);
		setTitle("Customized ERP");
		
		ob1 = new StakeholderUI();
		ob2 = new InvestorUI();
		ob3 = new FinanceUI();
		ob4 = new Customer_RelationUI();
		ob5 = new SalesUI();
		ob6 = new InventoryUI();
		ob7 = new VendorUI();
	    ob8 = new ProductionUI();
		
		createPanels();
		createMenu();	
		createButtons();
		addComponents();
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
	}
	
	void createPanels()
	{
		p1 = ob1.p;
		p2 = ob2.p;
		p3 = ob3.p;
		p4 = ob4.p;
        p5 = ob5.p;		
		p6 = ob6.p;
		p7 = ob7.p;
		p8 = ob8.p;
		pb = new JPanel(new FlowLayout(FlowLayout.CENTER,100,0));
		pb.setBounds(0,400,600,150);
	}
	
	void createMenu()
	{
		mb = new JMenuBar();
		
		m1 = new JButton("Stakeholder");
		m1.setFocusable(false);
		
		m2 = new JButton("Investor");
		m2.setFocusable(false);
		
		
		m3 = new JButton("Finance");
		m3.setFocusable(false);
		
		m4 = new JButton("Customer_Relation");
		m4.setFocusable(false);
		
		m5 = new JButton("Sales");
		m5.setFocusable(false);
		
		m6 = new JButton("Inventory");
		m6.setFocusable(false);
		
		m7 = new JButton("Vendor");
		m7.setFocusable(false);
		
		m8 = new JButton("Production");
		m8.setFocusable(false);
		
		
		m1.addActionListener(this);
		m2.addActionListener(this);
		m3.addActionListener(this);
		m4.addActionListener(this);
		m5.addActionListener(this);
		m6.addActionListener(this);
		m7.addActionListener(this);
		m8.addActionListener(this);
		
		mb.add(m1);
		mb.add(m2);
		mb.add(m3);
		mb.add(m4);
		mb.add(m5);
		mb.add(m6);
		mb.add(m7);
		mb.add(m8);
		
	}
	
	public void actionPerformed(ActionEvent e)
	{
		remove(p1);
		remove(p2);
		remove(p3);
		remove(p4);
		remove(p5);
		remove(p6);
		remove(p7);
		remove(p8);
		
		if(e.getSource()==m1)
			add(p1);
		
		else if(e.getSource()==m2)
			add(p2);
		
		else if(e.getSource()==m3)
			add(p3);
		
		else if(e.getSource()==m4)
			add(p4);
		else if(e.getSource()==m5)
			add(p5);
		else if(e.getSource()==m6)
			add(p6);
		else if(e.getSource()==m7)
			add(p7);
		else
			add(p8);
	}
	
	void createButtons()
	{
		submit = new JButton("Submit");
		submit.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(new JFrame(),"Successfully Inserted!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
			}
		});
		
		
		modify = new JButton("Modify");
		modify.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(new JFrame(),"Successfully Modified!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
			}
		});
		
		
		delete = new JButton("Delete");
		delete.addActionListener(new ActionListener()
		{
			public void actionPerformed(ActionEvent e)
			{
				JOptionPane.showMessageDialog(new JFrame(),"Successfully Deleted!","NOTICE",JOptionPane.INFORMATION_MESSAGE); 
			}
		});
		
		pb.add(submit);
		pb.add(modify);
		pb.add(delete);
	}
	
	void addComponents()
	{
		add(p1);
		add(p2);
		add(pb);
		setJMenuBar(mb);
	}
	
	public static void main(String a[])
	{
		new MainUI1();
	}
}
